Assumed Knowledge
=================
wip
