PLE with Keras
--------------
wip
