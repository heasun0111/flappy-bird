Available Games
----------------

.. toctree::
  /user/games/doom
  /user/games/catcher
  /user/games/monsterkong
  /user/games/flappybird
  /user/games/pixelcopter
  /user/games/pong
  /user/games/puckworld
  /user/games/raycastmaze
  /user/games/snake
  /user/games/waterworld
