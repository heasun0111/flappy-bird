from setuptools import setup

setup(name='gym_flappy_bird',
      version='0.1.0',
      install_requires=['gym', 'pygame']
)
