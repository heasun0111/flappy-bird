#!/usr/bin/bash
python3 -m pip install -e .