#!/usr/local/bin/python3
# -*- coding: utf-8 -*-
import gym
from gym import error, spaces, utils
from gym.utils import seeding


class FlappyBirdEnv(gym.Env):

    metadata = {'render.modes': ['human']}

    def __init__(self):
        pass

    def step(self, action):
        pass

    def reset(self):
        pass

    def render(self, mode='human', close=False):
        pass
