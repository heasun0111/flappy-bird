#!/usr/local/bin/python3
# -*- coding: utf-8 -*-
from gym_flappy_bird.envs.flappy_bird_env import FlappyBirdEnv
