#!/usr/local/bin/python3
# -*- coding: utf-8 -*-
import gym
import gym_flappy_bird      # noqa: F401

env = gym.make('flappy-bird-v0')

if __name__ == "__main__":
    pass
